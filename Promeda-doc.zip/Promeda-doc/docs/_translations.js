
function hnd_ut(a){
a.TRANSLATIONS['Search term too short'] = "Search term too short";
a.TRANSLATIONS['No results'] = "No results";
a.TRANSLATIONS['Please enter 3 or more characters'] = "Please enter 3 or more characters";
a.TRANSLATIONS['Word list not ready yet. Please wait until the word list is fully downloaded'] = "Word list not ready yet. Please wait until the word list is fully downloaded";
a.TRANSLATIONS['Incorrect or corrupt search data. Please check your HelpNDoc template'] = "Incorrect or corrupt search data. Please check your HelpNDoc template";
a.TRANSLATIONS['Related topics...'] = "Related topics...";
a.TRANSLATIONS['Loading...'] = "Loading...";
a.TRANSLATIONS['Close'] = "Close";
}
