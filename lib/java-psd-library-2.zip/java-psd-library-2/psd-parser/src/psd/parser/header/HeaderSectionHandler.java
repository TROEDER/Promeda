package psd.parser.header;

public interface HeaderSectionHandler {
	public void headerLoaded(Header header);
}
