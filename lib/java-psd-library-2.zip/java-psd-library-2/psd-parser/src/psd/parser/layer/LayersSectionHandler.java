package psd.parser.layer;

public interface LayersSectionHandler {
	public void createLayer(LayerParser parser);
	public void createBaseLayer(LayerParser parser);
}
