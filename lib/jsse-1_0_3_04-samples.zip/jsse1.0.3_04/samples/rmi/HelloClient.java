/*
 * @(#)HelloClient.java	1.2 00/06/21
 *
 * Copyright 1995-1998,2000 by Sun Microsystems, Inc.,
 * 901 San Antonio Road, Palo Alto, California, 94303, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Sun Microsystems, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Sun.
 */

import java.net.InetAddress;
import java.rmi.Naming;
import java.rmi.RemoteException;

public class HelloClient {

    public static void main(String args[]) {
	try {
	    // "obj" is the identifier that we'll use to refer
	    // to the remote object that implements the "Hello"
	    // interface
	    Hello obj = null;
	    obj = (Hello)Naming.lookup("//" +
		InetAddress.getLocalHost().getHostName() + "/HelloServer");

	    String message = "blank";
	    message = obj.sayHello();
	    System.out.println(message+"\n");
	} catch (Exception e) {
	    System.out.println("HelloClient exception: " + e.getMessage());
	    e.printStackTrace();
	}
    }
}
