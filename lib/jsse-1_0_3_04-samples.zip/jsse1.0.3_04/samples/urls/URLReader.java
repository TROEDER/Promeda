/*
 * @(#)URLReader.java	1.1 99/10/06
 *
 * Copyright 1995-1998 by Sun Microsystems, Inc.,
 * 901 San Antonio Road, Palo Alto, California, 94303, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Sun Microsystems, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Sun.
 */
import java.net.*;
import java.io.*;

/* 
 * This example illustrates using a URL to access resources
 * on a secure site.
 *
 * To use Sun's reference implementation of HTTPS protocol, Please set 
 * the following Java system property:
 * 
 *    java.protocol.handler.pkgs = com.sun.net.ssl.internal.www.protocol
 *
 * If you are running inside a firewall, please also set the following
 * Java system properties to the appropriate value:
 *
 *   https.proxyHost = <secure proxy server hostname>
 *   https.proxyPort = <secure proxy server port>
 * 
 */

public class URLReader {
    public static void main(String[] args) throws Exception {
	URL verisign = new URL("https://www.verisign.com/");
	BufferedReader in = new BufferedReader(
				new InputStreamReader(
				verisign.openStream()));

	String inputLine;

	while ((inputLine = in.readLine()) != null)
	    System.out.println(inputLine);

	in.close();
    }
}
