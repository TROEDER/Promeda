swingx-core
===========

Fork of swingx-core 1.6.5
